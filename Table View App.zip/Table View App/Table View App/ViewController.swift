//
//  ViewController.swift
//  Table View App
//
//  Created by Marshall, Christopher on 18/10/2018.
//  Copyright © 2018 Marshall, Christopher. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    struct myVariables{
        static var userInput = 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "myCell")
        
        let currentRow = indexPath.row+1
        let multiplication = String(currentRow * myVariables.userInput)
        let output = String(currentRow) + " x " + String(myVariables.userInput) + " = " + multiplication
        
        cell.textLabel?.text = output
        
        return cell
    }

    @IBOutlet weak var myTable: UITableView!
    
    
    @IBOutlet weak var textFieldInput: UITextField!
    @IBAction func submitBtn(_ sender: Any) {
        
        let inputNum = Int(textFieldInput.text!) ?? 0
        myVariables.userInput = inputNum
        
        myTable.reloadData()
        textFieldInput.resignFirstResponder()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

